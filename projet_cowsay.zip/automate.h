#ifndef __AUTOMATE__
#define __AUTOMATE__

void init_mon_automate(automate *A)  ;
void simule_automate() ;

#endif
#include "automate.h"

int main() {
	simule_automate() ;
return 0 ;
}
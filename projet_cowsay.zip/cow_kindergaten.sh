#!/bin/bash
cowsay 1
sleep 1
clear
cowsay 2
sleep 1
clear
cowsay 3
sleep 1
clear
cowsay 4
sleep 1
clear
cowsay 5
sleep 1
clear
cowsay 6
sleep 1
clear
cowsay 7
sleep 1
clear
cowsay 8
sleep 1
clear
cowsay 9
sleep 1
clear
cowsay -T U 10
